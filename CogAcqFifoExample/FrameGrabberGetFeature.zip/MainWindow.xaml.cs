﻿using Cognex.VisionPro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FrameGrabberGetFeature
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            List<GigECamInfo> camList = new List<GigECamInfo>();

            CogFrameGrabbers grabbers = new CogFrameGrabbers();
            if (grabbers.Count != 0)
            {
                //grabber.CreateAcqFifo("Generic GigEVision (Mono)", CogAcqFifoPixelFormatConstants.Format8Grey, 0, false);

                for (int i = 0; i < grabbers.Count; i++)
                {
                    ICogFrameGrabber grabber = grabbers[i];
                    ICogGigEAccess gigEAccess = grabber.OwnedGigEAccess;
                    string vendor = gigEAccess.GetFeature("DeviceVendorName");

                    camList.Add(new GigECamInfo() { Name = grabber.Name, SerialNumber = grabber.SerialNumber, VendorName = vendor });
                }
            }

            dataGrid.ItemsSource = camList;
        }
    }

    public class GigECamInfo
    {
        public string Name { get; set; }
        public string SerialNumber { get; set; }
        public string VendorName { get; set; }
    }
}
